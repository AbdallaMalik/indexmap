﻿<?php
ini_set('max_execution_time', 6000);
ini_set('memory_limit','3000M');
set_time_limit(0);
require_once('../panel/modules/config.php');
  
    $data = array();

		$myquery = "SELECT Unique_ID,Country,Price,Area as city,Lat as lat, Lng as lng 
	    FROM at_sta_agents 
	    WHERE Lat !='' LIMIT 10000"; 
  
       $query = mysqli_query($con,$myquery);
       
      while($x = mysqli_fetch_assoc($query)) {
           $data[]= $x ;
		  	
        }
		
		echo json_encode($data);
	
   
     
    mysqli_close($con);	
     

?>




