﻿<?php
ini_set('max_execution_time', 6000);
ini_set('memory_limit','3000M');
set_time_limit(0);
require_once('../panel/modules/config.php');
  

	$search = $_POST['search'];
	$myquery = "SELECT Unique_ID,Country,Price,PriceFt,Area as city,Lat as lat, Lng as lng 
	FROM at_real_estate 
	where Area like '%$search%' and Lat !=''"; 
	
	
  
    $query = mysqli_query($con,$myquery);
    $data = array();
    while($x = mysqli_fetch_assoc($query)) {
        $data[]= $x ;
    }
    	echo json_encode($data);
     
    mysqli_close($con);

?>




