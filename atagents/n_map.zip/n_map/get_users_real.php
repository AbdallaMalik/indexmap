﻿<?php
ini_set('max_execution_time', 6000);
ini_set('memory_limit','3000M');
set_time_limit(0);
require_once('../panel/modules/config.php');
  

	$country = $_POST['country'];	
		
		$myquery = "SELECT Unique_ID,Country,Price,Area as city,Lat as lat, Lng as lng 
	    FROM at_real_estate
	    where Country like '%$country%' and Lat !='' ORDER BY Unique_ID DESC"; 
	
  
    $query = mysqli_query($con,$myquery);
    $data = array();
    while($x = mysqli_fetch_assoc($query)) {
        $data[]= $x ;
    }
    	echo json_encode($data);
     
    mysqli_close($con);

?>




