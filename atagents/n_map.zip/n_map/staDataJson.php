﻿<?php
ini_set('max_execution_time', 6000);
ini_set('memory_limit','3000M');
set_time_limit(0);
require_once('../panel/modules/config.php');
  

	$country = $_POST['country'];
	$distPri = $_POST['distPri'];
	$min     = $_POST['minPrice'];
	$max     = $_POST['maxPrice'];
	
	
	
	if($min !="0" && $max !="0")
	{
		if($country !="")
	     {
		   $myquery = "SELECT Unique_ID,Country,Price,PriceFt,Area as city,Lat as lat, Lng as lng 
		   FROM at_sta_agents 
		   where Country like '%$country%' and Price between $min and $max and Lat !=''"; 	
	     }
	   else
	    {
		   $myquery = "SELECT Unique_ID,Country,Price,PriceFt,Area as city,Lat as lat, Lng as lng 
		   FROM at_sta_agents 
		   where Price between $min and $max and Lat !=''"; 	
	    }	
	}
	else
	{
		if($country !="")
	     {
		   $myquery = "SELECT Unique_ID,Country,Price,PriceFt,Area as city,Lat as lat, Lng as lng 
		   FROM at_sta_agents 
		   where Country like '%$country%' and Lat !=''"; 	
	     }
	   else
	    {
		   $myquery = "SELECT Unique_ID,Country,Price,PriceFt,Area as city,Lat as lat, Lng as lng 
		   FROM at_sta_agents 
		   where Lat !=''"; 	
	    }	
	}
	
	
	
  
    $query = mysqli_query($con,$myquery);
    $data = array();
    while($x = mysqli_fetch_assoc($query)) {
        $data[]= $x ;
    }
    	echo json_encode($data);
     
    mysqli_close($con);

?>




