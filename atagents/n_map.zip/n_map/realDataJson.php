﻿<?php
ini_set('max_execution_time', 6000);
ini_set('memory_limit','3000M');
set_time_limit(0);
require_once('../panel/modules/config.php');
  

    $currency= $_POST['currency'];
	
	$country = $_POST['country'];
	$distPri = $_POST['distPri'];
	$min     = $_POST['minPrice'];
	$max     = $_POST['maxPrice'];
    
	if($distPri =="PriFeet")
	{
		if($min !="" && $max !="")
	    {
			$min     = $_POST['minPrice'] / $currency;
	        $max     = $_POST['maxPrice'] / $currency;
		    if($country =="WorldWide")
	          {
		        $myquery = "SELECT Unique_ID,Country,Price,PriceFt,Area as city,Lat as lat, Lng as lng 
		        FROM at_real_estate 
		        where Lat !='' and PriceFt between $min and $max"; 	
	          }
	       else if($country !="" && $country !="WorldWide")
	         {
		       $myquery = "SELECT Unique_ID,Country,Price,PriceFt,Area as city,Lat as lat, Lng as lng 
		       FROM at_real_estate 
		       where Country like '%$country%' and PriceFt between $min and $max and Lat !=''"; 	
	        }
	      else
	       {
		       $myquery = "SELECT Unique_ID,Country,Price,PriceFt,Area as city,Lat as lat, Lng as lng 
		       FROM at_real_estate 
		       where Lat !='' and PriceFt between $min and $max"; 	
	       }	
		}
	   else
	     {
		if($country =="WorldWide")
	     {
		   $myquery = "SELECT Unique_ID,Country,Price,PriceFt,Area as city,Lat as lat, Lng as lng 
		   FROM at_real_estate 
		   where Lat !=''"; 	
	     }
	   else if($country !="" && $country !="WorldWide")
	    {
		   $myquery = "SELECT Unique_ID,Country,Price,PriceFt,Area as city,Lat as lat, Lng as lng 
		   FROM at_real_estate 
		   where Country like '%$country%' and Lat !=''"; 	
	    }
	   else
	    {
		   $myquery = "SELECT Unique_ID,Country,Price,PriceFt,Area as city,Lat as lat, Lng as lng 
		   FROM at_real_estate 
		   where Lat !='' limit 10000"; 	
	    }		
		 }
	
	}
	else
	{
		if($min !="" && $max !="")
	    {
			$min     = $_POST['minPrice'] / $currency;
	        $max     = $_POST['maxPrice'] / $currency;
		    if($country =="WorldWide")
	          {
		        $myquery = "SELECT Unique_ID,Country,Price,PriceFt,Area as city,Lat as lat, Lng as lng 
		        FROM at_real_estate 
		        where Lat !='' and Price between $min and $max"; 	
	          }
	       else if($country !="" && $country !="WorldWide")
	         {
		       $myquery = "SELECT Unique_ID,Country,Price,PriceFt,Area as city,Lat as lat, Lng as lng 
		       FROM at_real_estate 
		       where Country like '%$country%' and Price between $min and $max and Lat !=''"; 	
	        }
	      else
	       {
		       $myquery = "SELECT Unique_ID,Country,Price,PriceFt,Area as city,Lat as lat, Lng as lng 
		       FROM at_real_estate 
		       where Lat !='' and Price between $min and $max"; 	
	       }	
		}
	   else
	     {
		if($country =="WorldWide")
	     {
		   $myquery = "SELECT Unique_ID,Country,Price,PriceFt,Area as city,Lat as lat, Lng as lng 
		   FROM at_real_estate 
		   where Lat !=''"; 	
	     }
	   else if($country !="" && $country !="WorldWide")
	    {
		   $myquery = "SELECT Unique_ID,Country,Price,PriceFt,Area as city,Lat as lat, Lng as lng 
		   FROM at_real_estate 
		   where Country like '%$country%' and Lat !=''"; 	
	    }
	   else
	    {
		   $myquery = "SELECT Unique_ID,Country,Price,PriceFt,Area as city,Lat as lat, Lng as lng 
		   FROM at_real_estate 
		   where Lat !='' limit 10000"; 	
	    }		
		 }
	
		
	}
	
    $query = mysqli_query($con,$myquery);
    $data = array();
    while($x = mysqli_fetch_assoc($query)) {
        $data[]= $x ;
    }
    	echo json_encode($data);
     
    mysqli_close($con);

?>




